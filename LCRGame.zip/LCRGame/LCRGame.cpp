#include "pch.h"
#include <iostream>
#include "Rules.h"
#include "Player.h"
#include "Dice.h"

using namespace std;
using namespace System;
using namespace System::IO;


int main()
{
    // Reference to classes used in the program
    Rules rules;
    Player player;
    Dice dice;

    // Generates the rules from a text file
    rules.DisplayRules();

    player.numberOfPlayers = 0;

    // Prompts player to choose number of players
    player.ChooseNumberOfPlayers();

    // Prompt players to enter names
    player.EnterPlayerNames();
    cin.ignore();

    // While gameActive variable is true, the game will continue to be played
    bool gameActive = true;

    while (gameActive == true)
    {
        for (int i = 0; i < player.numberOfPlayers; i++)
        {
            int playerChipCount = player.playerChipCount[i];
            int currentChipCount = playerChipCount;

            int lastPlayerChipCount = player.playerChipCount[player.numberOfPlayers - 1];
            int currentLastPlayerChipCount = lastPlayerChipCount;

            int leftPlayerChipCount = player.playerChipCount[i - 1];
            int currentLeftPlayerChipCount = leftPlayerChipCount;

            int lastPlayer = player.numberOfPlayers - 1;
            int rightPlayerChipCount = player.playerChipCount[i + 1];
            int currentRightPlayerChipCount = rightPlayerChipCount;

            // If player has 3 or more dice, they will roll 3 dice
            if (playerChipCount >= 3)
            {
                cout << player.playerNames[i] + " press enter to roll the dice." << endl;
                cin.ignore();

                dice.RollThreeDice();

                currentChipCount = dice.DiceResult(dice.result1, i, currentChipCount);

                    if (i == 0 && dice.result1 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result1 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result1 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result1 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                currentChipCount = dice.DiceResult(dice.result2, i, currentChipCount);

                    if (i == 0 && dice.result2 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result2, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result2 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result2, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result2 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result2 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                currentChipCount = dice.DiceResult(dice.result3, i, currentChipCount);

                    if (i == 0 && dice.result3 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result3, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result3 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result3, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result3 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result3 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                //Update all player chip counts after the round is over
                player.playerChipCount[player.numberOfPlayers - 1] = currentLastPlayerChipCount;
                player.playerChipCount[i] = currentChipCount;
                player.playerChipCount[i - 1] = currentLeftPlayerChipCount;
                player.playerChipCount[i + 1] = currentRightPlayerChipCount;
            }

            // If player only has two chips, they roll only two dice
            else if (playerChipCount == 2)
            {
                cout << player.playerNames[i] + " press enter to roll the dice." << endl;
                cin.ignore();

                dice.RollTwoDice();

                currentChipCount = dice.DiceResult(dice.result1, i, currentChipCount);

                    if (i == 0 && dice.result1 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result1 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result1 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result1 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                currentChipCount = dice.DiceResult(dice.result2, i, currentChipCount);

                    if (i == 0 && dice.result2 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result2, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result2 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result2, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result2 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result2 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                // Update all player chip counts at the end of the round
                player.playerChipCount[player.numberOfPlayers - 1] = currentLastPlayerChipCount;
                player.playerChipCount[i] = currentChipCount;
                player.playerChipCount[i - 1] = currentLeftPlayerChipCount;
                player.playerChipCount[i + 1] = currentRightPlayerChipCount;

            }

            // If player chip count is 1, they only roll one die
            else if (playerChipCount == 1)
            {
            cout << player.playerNames[i] + " press enter to roll the dice." << endl;
            cin.ignore();

                dice.RollOneDie();

                currentChipCount = dice.DiceResult(dice.result1, i, currentChipCount);
                    if (i == 0 && dice.result1 == 1)
                    {
                        currentLastPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i > 0 && dice.result1 == 1)
                    {
                        currentLeftPlayerChipCount = dice.AddChips(dice.result1, i, currentLeftPlayerChipCount, currentLastPlayerChipCount);
                    }
                    else if (i == lastPlayer && dice.result1 == 2)
                    {
                        player.playerChipCount[0] = player.playerChipCount[0] + 1;
                    }
                    else if (i < lastPlayer && dice.result1 == 2)
                    {
                        currentRightPlayerChipCount = currentRightPlayerChipCount + 1;
                    }

                // Update player chip count after round is over
                player.playerChipCount[player.numberOfPlayers - 1] = currentLastPlayerChipCount;
                player.playerChipCount[i] = currentChipCount;
                player.playerChipCount[i - 1] = currentLeftPlayerChipCount;
                player.playerChipCount[i + 1] = currentRightPlayerChipCount;

            }

            // If player has no chips, they skip a turn
            else
            {
                cout << player.playerNames[i] + " has no more chips. Turn skipped." << endl;
            }            
        }

        // This loop displays each players chip count after each round
        for (int i = 0; i < player.numberOfPlayers; i++)
        {
            cout << player.playerNames[i] << "'s chip count is: " << player.playerChipCount[i] << " at the end of the round. " << endl;
        }
        cout << "\n";

        // This method checks to see if a player has won. If not, they game continues.
        gameActive = player.IsGameActive();
    }
    
    
    return 0;
}
