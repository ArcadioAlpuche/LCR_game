#include "pch.h"
#include <iostream>
#include "Rules.h"
#include "Player.h"
#include "Dice.h"

using namespace std;
using namespace System;
using namespace System::IO;


int main()
{
    Rules rules;
    Player player;
    Dice dice;

    //rules.DisplayRules();

    player.numberOfPlayers = 0;

    player.ChooseNumberOfPlayers();
    player.EnterPlayerNames();
    cin.ignore();

    for (int i = 0; i < player.numberOfPlayers; i++)
    {
        int playerChipCount = player.playerChipCount[i];
        cout << player.playerNames[i] + " press enter to roll the dice."<< endl;
        cin.ignore();
        //dice.RollDice(playerChipCount);
        
        if (playerChipCount >= 3)
        {
            dice.RollThreeDice();

            if (dice.result1 == 1 || dice.result1 == 2 || dice.result1 == 3)
            {
                i = i - 1;
                player.playerChipCount[i];
                cout << player.playerChipCount[i];
            }
            else if (dice.result2 == 1 ||dice.result1 == 2 || dice.result1 == 3)
            {
                i = i - 1;
                player.playerChipCount[i];
                cout << player.playerChipCount[i];
            }
            else if (dice.result3 == 1 || dice.result2 == 1 || dice.result3 == 1)
            {
                i = i - 1;
                player.playerChipCount[i];
                cout << player.playerChipCount[i];
            }

            /*switch (dice.result1)
            {
            case 1:
                player.playerChipCount[i - 1];
                cout << player.playerChipCount[i];
            case 2:
                player.playerChipCount[i - 1];
                cout << player.playerChipCount[i];
            case 3:
                player.playerChipCount[i - 1];
                cout << player.playerChipCount[i];
            default:
                break;
            }*/

            switch (dice.result2)
            {
            case 1:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            case 2:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            case 3:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            default:
                break;
            }

            switch (dice.result3)
            {
            case 1:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            case 2:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            case 3:
                player.playerChipCount[i] - 1;
                cout << player.playerChipCount[i];
            default:
                break;
            }
        }
        else if(playerChipCount == 2)
        {
            dice.RollTwoDice();
        }
        else if(playerChipCount == 1)
        {
            dice.RollOneDie();
        }
    }
    
    return 0;
}
