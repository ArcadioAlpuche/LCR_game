#include "pch.h"
#include "Player.h"


	void Player::ChooseNumberOfPlayers()
	{
		// If player number entered is less than 3, user is prompted to add more players
		while (numberOfPlayers < 3)
		{
			cout << "\nPlease enter number of players (Must be 3 or more players): " << endl;
			cin >> numberOfPlayers;

			for (int i = 0; i < numberOfPlayers; i++)
			{
				playerChipCount[i] = 3;
			}

			if (numberOfPlayers < 3)
			{
				cout << "LCR requires 3 or more players. Please add more players." << endl;
			}
		}
	}

	// Prompts players to enter their names
	void Player::EnterPlayerNames()
	{
		for (int i = 0; i < numberOfPlayers; i++)
		{
			cout << "Please enter player " << i + 1 << "'s name:\n";
			cin >> playerNames[i];
			cout << endl;
		}
	}

	// Checks to see if there is a winner or not
	bool Player::IsGameActive()
	{
		isChipCountZero = 0;

		for (int i = 0; i < numberOfPlayers; i++)
		{
			if (playerChipCount[i] == 0)
			{
				isChipCountZero = isChipCountZero + 1;

				if (isChipCountZero == numberOfPlayers -1)
				{
					WinnerMessage();
					return false;					
				}
			}
		}
		return true;
	}

	// Message for winner
	void Player::WinnerMessage()
	{
		for (int i = 0; i < numberOfPlayers; i++)
		{
			if (playerChipCount[i] != 0)
			{
				cout << "\nCongratulations " << playerNames[i] << "! You are the winner!" << endl;
			}
		}
	}



