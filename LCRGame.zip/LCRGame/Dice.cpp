#include "pch.h"
#include "Dice.h"
#include "Player.h"

void Dice::RollThreeDice()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);
		result2 = 1 + (rand() % 6);
		result3 = 1 + (rand() % 6);

		cout << "First die: " << result1 << "\n";
		cout << "Second die: " << result2 << "\n";
		cout << "Third die: " << result3 << "\n\n";
	}

void Dice::RollTwoDice()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);
		result2 = 1 + (rand() % 6);

		cout << "First die: " << result1 << "\n";
		cout << "Second die: " << result2 << "\n\n";
	}


void Dice::RollOneDie()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);

		cout << "You rolled a: " << result1 << "\n\n";
	}

int Dice::DiceResult(int result, int i, int ccc)
	{
	Player player;

		if (result == 1 || result == 2 || result == 3)
		{
			ccc = ccc - 1;

			switch (result)
			{
			case 1:
				cout << "You rolled L. Move 1 chip left.\n" << endl;
				break;
			case 2:
				cout << "You rolled R. Move 1 chip right.\n" << endl;
				break;
			case 3:
				cout << "You rolled C. Place 1 chip to the center.\n" << endl;
			default:
				break;
			}

			return ccc;

		}
		else 
		{
			return ccc;
		}
	}

int Dice::AddChips(int result, int i, int playersChips, int lpcc)
{
	if (result == 1 || result == 2)
	{
		if (i == 0)
		{
			lpcc = lpcc + 1;
			return lpcc;
		}
		else 
		{
			playersChips = playersChips + 1;
			return playersChips;
		}

	}

}