#pragma once
#include "pch.h"
#using<system.dll>

using namespace System;
using namespace System::IO;

ref class Rules
{

public: 
	void DisplayRules() 
	{
        String^ fileName = "lcr_rules.txt";
        try
        {
            StreamReader^ din = File::OpenText(fileName);

            String^ str;
            int count = 0;
            while ((str = din->ReadLine()) != nullptr)
            {
                count++;
                Console::WriteLine(str);
            }
        }
        catch (Exception ^ e)
        {
            if (dynamic_cast<FileNotFoundException^>(e))
                Console::WriteLine("file '{0}' not found", fileName);
            else
                Console::WriteLine("problem reading file '{0}'", fileName);
        }
	}
};

