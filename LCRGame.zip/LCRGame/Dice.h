#pragma once
#include <stdlib.h>
#include <iostream>
#include <time.h>
using namespace std;

ref class Dice
{
public: int result1;
public: int result2;
public: int result3;

public: 
	void RollThreeDice()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);
		result2 = 1 + (rand() % 6);
		result3 = 1 + (rand() % 6);

		cout << result1 << "\n";
		cout << result2 << "\n";
		cout << result3 << "\n\n";
	}
public: 
	void RollTwoDice()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);
		result2 = 1 + (rand() % 6);
	}

public:
	void RollOneDie()
	{
		srand((unsigned)time(0));
		result1 = 1 + (rand() % 6);
	}

public: 
	void VerifyResult(int result, int chipCount[])
	{
		switch (result)
		{
		case 1:
			chipCount - 1;
			cout << chipCount;
		default:
			break;
		}
	}
};

