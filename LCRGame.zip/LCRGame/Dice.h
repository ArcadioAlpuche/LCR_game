#pragma once
#include <stdlib.h>
#include <iostream>
#include <time.h>
using namespace std;

ref class Dice
{
	public: int result1;
			int result2;
			int result3;

			void RollThreeDice();
			void RollTwoDice();
			void RollOneDie();
			int DiceResult(int result, int i, int ccc);
			int AddChips(int result, int i, int playersChips, int lpcc);

};

