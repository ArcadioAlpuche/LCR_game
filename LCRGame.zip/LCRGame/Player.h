#pragma once
#include <string>
#include <iostream>

using namespace std;

class Player
{
	public: int numberOfPlayers;
			string playerNameEntry;
			string playerNames[100];
			int playerChipCount[100];
			int currentChipCount;
			int isChipCountZero = 0;

			void ChooseNumberOfPlayers();
			void EnterPlayerNames();
			bool IsGameActive();
			void WinnerMessage();


};

