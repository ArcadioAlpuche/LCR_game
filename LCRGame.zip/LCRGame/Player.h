#pragma once
#include <string>
#include <iostream>

using namespace std;

class Player
{
public: int numberOfPlayers;
public: string playerNameEntry;
public: string playerNames[100];
public: int playerChipCount[100];

public: 
	void ChooseNumberOfPlayers()
	{
        while (numberOfPlayers < 3)
        {
            cout << "\nPlease enter number of players (Must be 3 or more players): " << endl;
            cin >> numberOfPlayers;

            for (int i = 0; i < numberOfPlayers; i++)
            {
                playerChipCount[i] = 3;
            }

            if (numberOfPlayers < 3)
            {
                cout << "LCR requires 3 or more players. Please add more players." << endl;
            }
        }
	}

public: 
    void EnterPlayerNames()
    {
        for (int i = 0; i < numberOfPlayers; i++)
        {
            cout << "Please enter player " << i + 1 << "'s name:\n";
            cin >> playerNames[i];
            cout << endl;
        }
    }


};

